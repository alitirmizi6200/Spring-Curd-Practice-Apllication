package com.example.CurdPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurdPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurdPracticeApplication.class, args);
	}

}
