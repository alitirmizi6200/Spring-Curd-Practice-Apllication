package com.example.CurdPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurdPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
